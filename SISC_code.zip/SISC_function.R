## Likelihood for Structure S0 given the data
## (i.e., given a specific contingency table)
## 
##
## Input: "data", a contingency table with
##           data[1] = N(C=0, E=0)
##           data[2] = N(C=0, E=1)
##           data[3] = N(C=1, E=1)
##           data[4] = N(C=1, E=1)
##
##        "theta", a set of parameter vectors (samples from prior)
##           theta[,1] = b_c (base rate of cause)
##           theta[,2] = w_c (causal strength)
##           theta[,3] = w_a (strength of background) 
##

# defintion of alpha (Equation 3)

alpha <- 1.0

##

likelihood_data_S0 <- function(data, theta)
{
  ((1-theta[,1])*(1-theta[,3]))^data[1]*
  ((1-theta[,1])*theta[,3])^data[2]*
  (theta[,1]*(1-theta[,3]))^data[3]*
  (theta[,1]*theta[,3])^data[4]
}

## Likelihood for Structure S1 given the data
## (i.e., given a specific contingency table)
##
##
## Input: "data", a contingency table with
##           data[1] = N(C=0, E=0)
##           data[2] = N(C=0, E=1)
##           data[3] = N(C=1, E=1)
##           data[4] = N(C=1, E=1)
##
##        "theta", a set of parameter vectors (samples from prior)
##           theta[,1] = b_c (base rate of cause)
##           theta[,2] = w_c (causal strength)
##           theta[,3] = w_a (strength of background) 
##
likelihood_data_S1 <- function(data, theta)
{
  ((1-theta[,1])*(1-theta[,3]))^data[1]*
  ((1-theta[,1])*theta[,3])^data[2]*
  (theta[,1]*(1-theta[,2])*(1-theta[,3]))^data[3]*
  ((theta[,2]+theta[,3]-theta[,2]*theta[,3])*theta[,1])^data[4]
}

## (Bayesian) CN model predictions (Equation 2): P(c->e|c,e) given Structure S0 and the data
## (i.e., given a specific contingency table)
## is set to 0 for S0 because under S0 the cause never produces the effect
##
## Input: "data", a contingency table with
##           data[1] = N(C=0, E=0)
##           data[2] = N(C=0, E=1)
##           data[3] = N(C=1, E=1)
##           data[4] = N(C=1, E=1)
##
##        "theta", a set of parameter vectors (samples from prior)
##           theta[,1] = b_c (base rate of cause)
##           theta[,2] = w_c (causal strength)
##           theta[,3] = w_a (strength of background) 
##
p_CattrE_S0 <- function(data, theta)
{
  pCattrE <- 0
  return(mean(pCattrE*likelihood_data_S0(data, theta))/mean(likelihood_data_S0(data, theta)))
}

## (Bayesian) CN model predictions (Equation 2): P(c->e|c,e) given Structure S0 and the data
## (i.e., given a specific contingency table)
##
##
## Input: "data", a contingency table with
##           data[1] = N(C=0, E=0)
##           data[2] = N(C=0, E=1)
##           data[3] = N(C=1, E=1)
##           data[4] = N(C=1, E=1)
##
##        "theta", a set of parameter vectors (samples from prior)
##           theta[,1] = b_c (base rate of cause)
##           theta[,2] = w_c (causal strength)
##           theta[,3] = w_a (strength of background) 
##
p_CattrE_S1 <- function(data, theta)
{
  pCattrE <- theta[,2]/(theta[,2]+theta[,3]-theta[,2]*theta[,3])
  return(mean(pCattrE*likelihood_data_S1(data, theta))/mean(likelihood_data_S1(data, theta)))
}


## Refined Equation (Equation 3): P(c->e|c,e) given Structure S0 and the data
## (i.e., given a specific contingency table)
##
##
## Input: "data", a contingency table with
##           data[1] = N(C=0, E=0)
##           data[2] = N(C=0, E=1)
##           data[3] = N(C=1, E=1)
##           data[4] = N(C=1, E=1)
##
##        "theta", a set of parameter vectors (samples from prior)
##           theta[,1] = b_c (base rate of cause)
##           theta[,2] = w_c (causal strength)
##           theta[,3] = w_a (strength of background) 
##
p_CsingE_S0 <- function(data, theta)
{
  pCsingE <- 0
  return(mean(pCsingE*likelihood_data_S0(data, theta))/mean(likelihood_data_S0(data, theta)))
}

## Refined Equation (Equation 3): P(c->e|c,e) given Structure S1 and the data
## 
## 
##
## Input: "data", a contingency table with
##           data[1] = N(C=0, E=0)
##           data[2] = N(C=0, E=1)
##           data[3] = N(C=1, E=1)
##           data[4] = N(C=1, E=1)
##
##        "theta", a set of parameter vectors (samples from prior)
##           theta[,1] = b_c (base rate of cause)
##           theta[,2] = w_c (causal strength)
##           theta[,3] = w_a (strength of background) 
##
p_CsingE_S1 <- function(data, theta)
{
  pCsingE <- (theta[,2]*(1-(alpha*theta[,3])))/(theta[,2]+theta[,3]-theta[,2]*theta[,3])  
  return(mean(pCsingE*likelihood_data_S1(data, theta))/mean(likelihood_data_S1(data, theta)))
}

## MAIN FUNCTION - generates SI predictions
## 
## Input: "data", a set of contingency tables (rows) with
##           data[,1] = N(C=0, E=0)
##           data[,2] = N(C=0, E=1)
##           data[,3] = N(C=1, E=0)
##           data[,4] = N(C=1, E=1)
##
##        "m", number of bootstrap samples to be drawn
##
## Output: a matrix with columns:
##           N_00    = N(C=0, E=0), corresponding to data[,1]
##           N_01    = N(C=0, E=1), corresponding to data[,2]
##           N_10    = N(C=1, E=0), corresponding to data[,3]
##           N_11    = N(C=1, E=1), corresponding to data[,4]
##           wc_MLE  = causal power according to data
##           bc_MLE  = base rate of cause according to data
##           wa_MLE  = base rate of effect according to data
##           pEC_MLE = predictive probability P(E|C) according to data
##           pCE_MLE = diagnostic probability P(C|E) according to data (i.e., simple Bayes)
##		 S0_pp   = posterior probabilty of Struture S0 given data
##		 S1_pp   = posterior probabilty of Struture S1 given data
##		 S0_pCsingE  = P(c->e|c,e) using Equation 3 given Struture S0 and data
##		 S1_pCsingE  = P(c->e|c,e) using Equation 3 given Struture S1 and data
##           SI_mean_pCsingE = avereage P(c->e|c,e) (i.e., prediction of the SISC)
##		 S0_pCattrE  = P(c->e|c,e) using Equation 2 (CN model) given Struture S0 and data
##		 S1_pCattrE  = P(c->e|c,e) using Equation 2 (CN model) given Struture S1 and data (i.e., Bayesian version of CN, incorporating parameter uncertainty)
##           SI_mean_pCattrE = avereage P(c->e|c,e) (i.e., prediction of SISC-CN Model, incorporating structure and parameter uncertainty)
##
generate_SI_preds <- function(data, m)
{
  pred <- matrix(data=0, nrow = dim(data)[1], ncol=11,
                 dimnames = list(1:dim(data)[1],
                                 c("N_00", "N_01", "N_10", "N_11",
                                   "wc_MLE", "bc_MLE", "wa_MLE",
                                   "pEC_MLE", "pCE_MLE",
                                   "S0_pp", "S1_pp")))
  pred <- as.data.frame(pred)
  
  pred$N_00 <- data[,1]
  pred$N_01 <- data[,2]
  pred$N_10 <- data[,3]
  pred$N_11 <- data[,4]
  
  # calculate causal power, base rates and conditional probabilities within each sample
  pred$wc_MLE   <- (data[,4]/(data[,3]+data[,4]) - data[,2]/(data[,1]+data[,2]))/(data[,1]/(data[,1]+data[,2]))
  pred$bc_MLE   <- rowSums(data[,3:4])/rowSums(data[,1:4])
  pred$wa_MLE   <- data[,2]/(data[,1]+data[,2])
  pred$pEC_MLE  <- data[,4]/(data[,3]+data[,4])
  pred$pCE_MLE  <- data[,4]/(data[,2]+data[,4])
  
  #draw flat priors for S1
  theta_S1 <- matrix(data=0, nrow=m, ncol=3)
  theta_S1[,1] <- rbeta(m, 1, 1)
  theta_S1[,2] <- rbeta(m, 1, 1)
  theta_S1[,3] <- rbeta(m, 1, 1)
  
  #draw flat priors for S0 (and ignore wc by setting it to zero)
  theta_S0 <- matrix(data=0, nrow=m, ncol=3)
  theta_S0[,1] <- rbeta(m, 1, 1)
  theta_S0[,2] <- rep(0, m)
  theta_S0[,3] <- rbeta(m, 1, 1)
  
  #for each contingency table:
  for (i in 1:dim(data)[1])
  {
    #unnormalized posterior of S0
    pred$S0_pp[i] <- mean(likelihood_data_S0(data[i,], theta_S0))*(1/2)
    #unnormalized posterior of S1
    pred$S1_pp[i] <- mean(likelihood_data_S1(data[i,], theta_S1))*(1/2)
    
    #singular causation (c-alone) probs given each structure
    pred$S0_pCsingE[i] <- p_CsingE_S0(data[i,], theta_S0)
    pred$S1_pCsingE[i] <- p_CsingE_S1(data[i,], theta_S1)
    
    #singular causation probs given each structure
    pred$S0_pCattrE[i] <- p_CattrE_S0(data[i,], theta_S0)
    pred$S1_pCattrE[i] <- p_CattrE_S1(data[i,], theta_S1)
  }
  
  #normalize posterior over structures
  pred[,c("S0_pp", "S1_pp")] <- pred[,c("S0_pp", "S1_pp")]/rowSums(pred[,c("S0_pp", "S1_pp")])
  
  #calculate Bayesian model average over singular causation probs (i.e., prediction of SISC)
  pred$SI_mean_pCsingE <- pred$S0_pp*pred$S0_pCsingE + pred$S1_pp*pred$S1_pCsingE
  
  #calculate Bayesian model average over CN model singular causation probs (i.e., prediction of SISC using CN model Equation)
  pred$SI_mean_pCattrE <- pred$S0_pp*pred$S0_pCattrE + pred$S1_pp*pred$S1_pCattrE
  
  return(pred)
}