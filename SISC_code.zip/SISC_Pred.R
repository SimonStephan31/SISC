# set working directory 
setwd("?") # set working directory here

#Select source!
source("SISC_function.r") # file with functions

## contingency tables used in Experiment 2
data <- matrix(data=0, nrow=15, ncol=4)
#             D  C  B  A              
data[1,]  <- c(0, 8, 0, 8)  
data[2,]  <- c(2, 6, 2, 6) 
data[3,]  <- c(4, 4, 4, 4) 
data[4,]  <- c(6, 2, 6, 2) 
data[5,]  <- c(8, 0, 8, 0) 
data[6,]  <- c(2, 6, 0, 8) 
data[7,]  <- c(4, 4, 2, 6) 
data[8,]  <- c(6, 2, 4, 4) 
data[9,]  <- c(8, 0, 6, 2)

data[10,]  <- c(4, 4, 0, 8)  
data[11,]  <- c(6, 2, 2, 6) 
data[12,]  <- c(8, 0, 4, 4) 
data[13,]  <- c(6, 2, 0, 8) 
data[14,]  <- c(8, 0, 2, 6) 
data[15,]  <- c(8, 0, 0, 8) 

## generate and show predictions of SISC
## (see "SISC_function.r" for explanations)
pred <- generate_SI_preds(data, 1000000)
(pred)



